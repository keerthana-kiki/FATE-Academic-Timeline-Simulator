package fate.service;

import fate.dao.CareerOutcomeDAO;
import fate.dao.SimulationDAO;
import fate.dao.TimelineEventDAO;
import fate.model.CareerOutcome;
import fate.model.Simulation;
import fate.model.TimelineEvent;
import fate.util.ConsoleHelper;

import java.sql.SQLException;
import java.util.List;

/**
 * Formats and prints timelines and career outcomes to the console.
 */
public class TimelineDisplayService {
    private final SimulationDAO simulationDAO = new SimulationDAO();
    private final TimelineEventDAO timelineEventDAO = new TimelineEventDAO();
    private final CareerOutcomeDAO careerOutcomeDAO = new CareerOutcomeDAO();

    public void listSimulationsForStudent(int studentId) {
        try {
            List<Simulation> list = simulationDAO.findByStudentId(studentId);
            if (list.isEmpty()) {
                ConsoleHelper.println("No simulations found for this student. Run a simulation first.");
                return;
            }
            ConsoleHelper.println("--- Your simulations ---");
            for (Simulation s : list) {
                ConsoleHelper.println("  " + s.getId() + ": " + s.getName() + " (" + (s.getScenarioNote() != null ? s.getScenarioNote() : "") + ")");
            }
        } catch (SQLException e) {
            ConsoleHelper.println("Database error: " + e.getMessage());
        }
    }

    public void showSimulationDetail(int simulationId) {
        try {
            Simulation sim = simulationDAO.findById(simulationId);
            if (sim == null) {
                ConsoleHelper.println("Simulation not found.");
                return;
            }
            ConsoleHelper.println("\n=== " + sim.getName() + " ===");
            if (sim.getScenarioNote() != null && !sim.getScenarioNote().isEmpty()) {
                ConsoleHelper.println("Scenario: " + sim.getScenarioNote());
            }

            List<TimelineEvent> events = timelineEventDAO.findBySimulationId(simulationId);
            ConsoleHelper.println("\n--- Timeline ---");
            if (events.isEmpty()) {
                ConsoleHelper.println("  (No events)");
            } else {
                for (TimelineEvent e : events) {
                    String sem = e.getSemesterLabel() != null ? " [" + e.getSemesterLabel() + "]" : "";
                    ConsoleHelper.println("  " + e.getSequenceOrder() + "." + sem + " " + e.getEventType() + ": " + e.getDescription());
                }
            }

            List<CareerOutcome> outcomes = careerOutcomeDAO.findBySimulationId(simulationId);
            ConsoleHelper.println("\n--- Career outcomes ---");
            if (outcomes.isEmpty()) {
                ConsoleHelper.println("  (None)");
            } else {
                for (CareerOutcome c : outcomes) {
                    ConsoleHelper.println("  * " + c.getPredictedRole() + " (" + c.getIndustry() + ") - Confidence: " + c.getConfidence() + "%");
                    if (c.getReasoningText() != null && !c.getReasoningText().isEmpty()) {
                        ConsoleHelper.println("    " + c.getReasoningText());
                    }
                }
            }
            ConsoleHelper.println("");
        } catch (SQLException e) {
            ConsoleHelper.println("Database error: " + e.getMessage());
        }
    }
}
