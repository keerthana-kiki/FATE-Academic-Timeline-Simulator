package fate.service;

import fate.dao.*;
import fate.model.*;
import fate.util.ConsoleHelper;

import java.sql.SQLException;
import java.util.List;

/**
 * Orchestrates student creation, selection, and data entry (academic, skills, interests, decisions).
 */
public class StudentService {
    private final StudentDAO studentDAO = new StudentDAO();
    private final AcademicSnapshotDAO snapshotDAO = new AcademicSnapshotDAO();
    private final CourseDAO courseDAO = new CourseDAO();
    private final EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private final SkillDAO skillDAO = new SkillDAO();
    private final InterestDAO interestDAO = new InterestDAO();
    private final StudentSkillDAO studentSkillDAO = new StudentSkillDAO();
    private final StudentInterestDAO studentInterestDAO = new StudentInterestDAO();
    private final DecisionPointDAO decisionPointDAO = new DecisionPointDAO();

    public Student createStudent(String name, String email) {
        Student s = new Student();
        s.setName(name);
        s.setEmail(email);
        try {
            studentDAO.insert(s);
            return s;
        } catch (SQLException e) {
            ConsoleHelper.println("Database error: " + e.getMessage());
            return null;
        }
    }

    public List<Student> listAllStudents() {
        try {
            return studentDAO.findAll();
        } catch (SQLException e) {
            ConsoleHelper.println("Database error: " + e.getMessage());
            return List.of();
        }
    }

    public Student getStudentById(int id) {
        try {
            return studentDAO.findById(id);
        } catch (SQLException e) {
            ConsoleHelper.println("Database error: " + e.getMessage());
            return null;
        }
    }

    public void runNewStudentFlow() {
        String name = ConsoleHelper.readLine("Enter student name: ");
        if (name.isEmpty()) {
            ConsoleHelper.println("Name cannot be empty.");
            return;
        }
        String email = ConsoleHelper.readLine("Enter email: ");
        if (email.isEmpty()) email = name.replaceAll("\\s+", "") + "@example.com";
        Student s = createStudent(name, email);
        if (s != null) ConsoleHelper.println("Student created with ID: " + s.getId());
    }

    public Student runSelectStudentFlow() {
        List<Student> list = listAllStudents();
        if (list.isEmpty()) {
            ConsoleHelper.println("No students found. Create one first.");
            return null;
        }
        ConsoleHelper.println("--- Students ---");
        for (Student s : list) {
            ConsoleHelper.println("  " + s.getId() + ": " + s.getName() + " (" + s.getEmail() + ")");
        }
        int id = ConsoleHelper.readInt("Enter student ID: ", 1, Integer.MAX_VALUE);
        Student s = getStudentById(id);
        if (s == null) ConsoleHelper.println("Student not found.");
        return s;
    }

    public void runEnterAcademicDataFlow(Student student) {
        if (student == null) {
            ConsoleHelper.println("Please select a student first.");
            return;
        }
        ConsoleHelper.println("--- Academic snapshot (semester) ---");
        String semester = ConsoleHelper.readLine("Semester label (e.g. Y1S1, Y2S2): ");
        if (semester.isEmpty()) return;
        double gpa = ConsoleHelper.readDouble("GPA (0-4): ", 0, 4);
        int credits = ConsoleHelper.readInt("Total credits earned so far: ", 0, 500);
        ConsoleHelper.println("Standing: 1=DEANS_LIST 2=GOOD_STANDING 3=PROBATION 4=WARNING");
        int standingChoice = ConsoleHelper.readInt("Choice (1-4): ", 1, 4);
        String standing = new String[]{"DEANS_LIST", "GOOD_STANDING", "PROBATION", "WARNING"}[standingChoice - 1];

        AcademicSnapshot a = new AcademicSnapshot();
        a.setStudentId(student.getId());
        a.setSemesterLabel(semester);
        a.setGpa(gpa);
        a.setTotalCredits(credits);
        a.setStanding(standing);
        try {
            snapshotDAO.insert(a);
            ConsoleHelper.println("Academic snapshot saved.");
        } catch (SQLException e) {
            ConsoleHelper.println("Database error: " + e.getMessage());
        }

        ConsoleHelper.println("Add course enrollments for this semester? 1=Yes 0=No");
        int addEnroll = ConsoleHelper.readInt("Choice: ", 0, 1);
        if (addEnroll == 1) {
            List<Course> courses = listCourses();
            if (courses.isEmpty()) return;
            for (Course c : courses) {
                ConsoleHelper.println("  " + c.getId() + ": " + c.getCode() + " - " + c.getName());
            }
            ConsoleHelper.println("Enter course ID to enroll (0 to stop): ");
            while (true) {
                int cid = ConsoleHelper.readInt("Course ID: ", 0, 9999);
                if (cid == 0) break;
                Course course = null;
                try {
                    course = courseDAO.findById(cid);
                } catch (SQLException ex) {
                    ConsoleHelper.println("Error looking up course: " + ex.getMessage());
                }
                if (course == null) {
                    ConsoleHelper.println("Course ID not found. Use an ID from the list above.");
                    ConsoleHelper.println("Add another? 1=Yes 0=No");
                    if (ConsoleHelper.readInt("Choice: ", 0, 1) == 0) break;
                    continue;
                }
                String grade = ConsoleHelper.readLine("Grade (e.g. A, B+, 3.5): ");
                if (grade.isEmpty()) grade = "B";
                Enrollment e = new Enrollment();
                e.setStudentId(student.getId());
                e.setCourseId(cid);
                e.setSemesterLabel(semester);
                e.setGrade(grade);
                e.setAlternate(false);
                try {
                    enrollmentDAO.insert(e);
                    ConsoleHelper.println("Enrollment added.");
                } catch (SQLException ex) {
                    ConsoleHelper.println("Error: " + ex.getMessage());
                }
                ConsoleHelper.println("Add another? 1=Yes 0=No");
                if (ConsoleHelper.readInt("Choice: ", 0, 1) == 0) break;
            }
        }
    }

    public List<Course> listCourses() {
        try {
            return courseDAO.findAll();
        } catch (SQLException e) {
            ConsoleHelper.println("Database error: " + e.getMessage());
            return List.of();
        }
    }

    public void runSkillsAndInterestsFlow(Student student) {
        if (student == null) {
            ConsoleHelper.println("Please select a student first.");
            return;
        }
        try {
            List<Skill> skills = skillDAO.findAll();
            ConsoleHelper.println("--- Skills (level 1-5) ---");
            for (Skill s : skills) ConsoleHelper.println("  " + s.getId() + ": " + s.getName());
            int sid = ConsoleHelper.readInt("Skill ID to add (0 to skip): ", 0, 9999);
            if (sid != 0) {
                try {
                    if (skillDAO.findById(sid) == null) {
                        ConsoleHelper.println("Skill ID not found. Use an ID from the list above.");
                    } else {
                        int level = ConsoleHelper.readInt("Level (1-5): ", 1, 5);
                        String sem = ConsoleHelper.readLine("Semester acquired (optional): ");
                        studentSkillDAO.insert(student.getId(), sid, level, sem.isEmpty() ? null : sem);
                        ConsoleHelper.println("Skill added.");
                    }
                } catch (SQLException ex) {
                    ConsoleHelper.println("Error: " + ex.getMessage());
                }
            }

            List<Interest> interests = interestDAO.findAll();
            ConsoleHelper.println("--- Interests (strength 1-5) ---");
            for (Interest i : interests) ConsoleHelper.println("  " + i.getId() + ": " + i.getName());
            int iid = ConsoleHelper.readInt("Interest ID to add (0 to skip): ", 0, 9999);
            if (iid != 0) {
                try {
                    if (interestDAO.findById(iid) == null) {
                        ConsoleHelper.println("Interest ID not found. Use an ID from the list above.");
                    } else {
                        int strength = ConsoleHelper.readInt("Strength (1-5): ", 1, 5);
                        studentInterestDAO.insert(student.getId(), iid, strength);
                        ConsoleHelper.println("Interest added.");
                    }
                } catch (SQLException ex) {
                    ConsoleHelper.println("Error: " + ex.getMessage());
                }
            }
        } catch (SQLException e) {
            ConsoleHelper.println("Database error: " + e.getMessage());
        }
    }

    public void runAddDecisionPointsFlow(Student student) {
        if (student == null) {
            ConsoleHelper.println("Please select a student first.");
            return;
        }
        String semester = ConsoleHelper.readLine("Semester label for this decision: ");
        if (semester.isEmpty()) return;
        ConsoleHelper.println("Decision type: 1=SPECIALIZATION_SWITCH 2=SKILL_FOCUS 3=COURSE_DROP 4=EXTRA_COURSE 5=GAP_SEMESTER 6=OTHER");
        int typeChoice = ConsoleHelper.readInt("Choice (1-6): ", 1, 6);
        String[] types = {"SPECIALIZATION_SWITCH", "SKILL_FOCUS", "COURSE_DROP", "EXTRA_COURSE", "GAP_SEMESTER", "OTHER"};
        String decisionType = types[typeChoice - 1];
        String detail = ConsoleHelper.readLine("Choice detail (what you decided): ");
        int impact = ConsoleHelper.readInt("Impact weight (1-5): ", 1, 5);

        DecisionPoint d = new DecisionPoint();
        d.setStudentId(student.getId());
        d.setSemesterLabel(semester);
        d.setDecisionType(decisionType);
        d.setChoiceDetail(detail);
        d.setImpactWeight(impact);
        try {
            decisionPointDAO.insert(d);
            ConsoleHelper.println("Decision point saved.");
        } catch (SQLException e) {
            ConsoleHelper.println("Database error: " + e.getMessage());
        }
    }
}
