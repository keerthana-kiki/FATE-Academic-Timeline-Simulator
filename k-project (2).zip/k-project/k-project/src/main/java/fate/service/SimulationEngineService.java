package fate.service;

import fate.dao.*;
import fate.model.*;
import fate.util.ConsoleHelper;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Builds alternate academic timelines and career outcomes from student data using rule-based logic.
 */
public class SimulationEngineService {
    private final DatabaseConnectionSupplier connectionSupplier;
    private final AcademicSnapshotDAO snapshotDAO = new AcademicSnapshotDAO();
    private final EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private final CourseDAO courseDAO = new CourseDAO();
    private final StudentSkillDAO studentSkillDAO = new StudentSkillDAO();
    private final SkillDAO skillDAO = new SkillDAO();
    private final DecisionPointDAO decisionPointDAO = new DecisionPointDAO();
    private final SimulationDAO simulationDAO = new SimulationDAO();
    private final SimulationDecisionDAO simulationDecisionDAO = new SimulationDecisionDAO();
    private final TimelineEventDAO timelineEventDAO = new TimelineEventDAO();
    private final CareerOutcomeDAO careerOutcomeDAO = new CareerOutcomeDAO();
    private final StudentInterestDAO studentInterestDAO = new StudentInterestDAO();
    private final InterestDAO interestDAO = new InterestDAO();

    public interface DatabaseConnectionSupplier {
        Connection get() throws SQLException;
    }

    public SimulationEngineService(DatabaseConnectionSupplier supplier) {
        this.connectionSupplier = supplier;
    }

    /**
     * Runs a base timeline simulation (no overrides) and persists simulation, timeline_events, career_outcomes.
     */
    public Simulation runBaseSimulation(int studentId, String simulationName, String scenarioNote) {
        return runSimulation(studentId, simulationName, scenarioNote, null);
    }

    /**
     * Runs a what-if simulation with optional decision overrides. Map: decisionPointId -> alternateChoice.
     */
    public Simulation runSimulation(int studentId, String simulationName, String scenarioNote, Map<Integer, String> alternateDecisions) {
        try (Connection conn = connectionSupplier.get()) {
            conn.setAutoCommit(false);
            try {
                Simulation sim = new Simulation();
                sim.setStudentId(studentId);
                sim.setName(simulationName != null && !simulationName.isEmpty() ? simulationName : "Simulation");
                sim.setScenarioNote(scenarioNote);
                simulationDAO.insert(conn, sim);
                int simId = sim.getId();

                if (alternateDecisions != null && !alternateDecisions.isEmpty()) {
                    for (Map.Entry<Integer, String> e : alternateDecisions.entrySet()) {
                        simulationDecisionDAO.insert(conn, simId, e.getKey(), e.getValue());
                    }
                }

                List<TimelineEvent> events = buildTimelineEvents(studentId, simId, alternateDecisions != null ? alternateDecisions : Map.of());
                for (TimelineEvent ev : events) {
                    timelineEventDAO.insert(conn, ev);
                }

                List<CareerOutcome> outcomes = buildCareerOutcomes(studentId, simId);
                for (CareerOutcome co : outcomes) {
                    careerOutcomeDAO.insert(conn, co);
                }

                conn.commit();
                return sim;
            } catch (Exception e) {
                conn.rollback();
                throw e;
            }
        } catch (Exception e) {
            ConsoleHelper.println("Error: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName()));
            return null;
        }
    }

    private List<String> orderedSemesters(int studentId) throws SQLException {
        Set<String> semesters = new HashSet<>();
        for (AcademicSnapshot a : snapshotDAO.findByStudentId(studentId)) {
            semesters.add(a.getSemesterLabel());
        }
        for (Enrollment e : enrollmentDAO.findByStudentIdAndAlternate(studentId, false)) {
            semesters.add(e.getSemesterLabel());
        }
        List<String> list = new ArrayList<>(semesters);
        Collections.sort(list);
        return list;
    }

    private List<TimelineEvent> buildTimelineEvents(int studentId, int simulationId, Map<Integer, String> alternateChoices) throws SQLException {
        List<TimelineEvent> events = new ArrayList<>();
        List<String> semesters = orderedSemesters(studentId);
        if (semesters.isEmpty()) {
            TimelineEvent ev = new TimelineEvent();
            ev.setSimulationId(simulationId);
            ev.setSequenceOrder(1);
            ev.setSemesterLabel(null);
            ev.setEventType("MILESTONE");
            ev.setDescription("No academic data yet. Add semesters and enrollments to see a timeline.");
            ev.setImpactScore(null);
            events.add(ev);
            return events;
        }

        Map<String, AcademicSnapshot> snapshotBySemester = new HashMap<>();
        for (AcademicSnapshot a : snapshotDAO.findByStudentId(studentId)) {
            snapshotBySemester.put(a.getSemesterLabel(), a);
        }
        List<Enrollment> enrollments = enrollmentDAO.findByStudentIdAndAlternate(studentId, false);
        Map<String, List<Enrollment>> enrollmentsBySemester = enrollments.stream().collect(Collectors.groupingBy(Enrollment::getSemesterLabel));
        List<StudentSkillDAO.Row> skillRows = studentSkillDAO.findByStudentId(studentId);
        Map<String, List<StudentSkillDAO.Row>> skillsBySemester = new HashMap<>();
        for (StudentSkillDAO.Row r : skillRows) {
            String sem = r.getSemesterAcquired() != null ? r.getSemesterAcquired() : "";
            skillsBySemester.computeIfAbsent(sem, k -> new ArrayList<>()).add(r);
        }
        List<DecisionPoint> decisions = decisionPointDAO.findByStudentId(studentId);
        Map<String, List<DecisionPoint>> decisionsBySemester = decisions.stream().collect(Collectors.groupingBy(DecisionPoint::getSemesterLabel));

        int order = 0;
        for (String sem : semesters) {
            AcademicSnapshot snap = snapshotBySemester.get(sem);
            if (snap != null && "DEANS_LIST".equals(snap.getStanding())) {
                TimelineEvent ev = new TimelineEvent();
                ev.setSimulationId(simulationId);
                ev.setSequenceOrder(++order);
                ev.setSemesterLabel(sem);
                ev.setEventType("MILESTONE");
                ev.setDescription("Dean's List - " + sem);
                ev.setImpactScore(4);
                events.add(ev);
            }

            for (Enrollment enr : enrollmentsBySemester.getOrDefault(sem, List.of())) {
                Course c = courseDAO.findById(enr.getCourseId());
                String courseName = c != null ? c.getCode() + " " + c.getName() : "Course " + enr.getCourseId();
                TimelineEvent ev = new TimelineEvent();
                ev.setSimulationId(simulationId);
                ev.setSequenceOrder(++order);
                ev.setSemesterLabel(sem);
                ev.setEventType("COURSE_TAKEN");
                ev.setDescription(courseName + " - Grade: " + enr.getGrade());
                ev.setImpactScore(3);
                events.add(ev);
            }

            for (StudentSkillDAO.Row r : skillsBySemester.getOrDefault(sem, List.of())) {
                Skill sk = skillDAO.findById(r.getSkillId());
                String skillName = sk != null ? sk.getName() : "Skill " + r.getSkillId();
                TimelineEvent ev = new TimelineEvent();
                ev.setSimulationId(simulationId);
                ev.setSequenceOrder(++order);
                ev.setSemesterLabel(sem);
                ev.setEventType("SKILL_GAINED");
                ev.setDescription(skillName + " (level " + r.getLevel() + ")");
                ev.setImpactScore(r.getLevel());
                events.add(ev);
            }

            for (DecisionPoint dp : decisionsBySemester.getOrDefault(sem, List.of())) {
                String choice = alternateChoices.getOrDefault(dp.getId(), dp.getChoiceDetail());
                if (choice == null) choice = dp.getChoiceDetail();
                TimelineEvent ev = new TimelineEvent();
                ev.setSimulationId(simulationId);
                ev.setSequenceOrder(++order);
                ev.setSemesterLabel(sem);
                ev.setEventType("DECISION_MADE");
                ev.setDescription(dp.getDecisionType() + ": " + (choice != null ? choice : "(no detail)"));
                ev.setImpactScore(dp.getImpactWeight());
                events.add(ev);
            }
        }
        // Skills with no semester (null or empty) appear at end of timeline
        for (StudentSkillDAO.Row r : skillsBySemester.getOrDefault("", List.of())) {
            Skill sk = skillDAO.findById(r.getSkillId());
            String skillName = sk != null ? sk.getName() : "Skill " + r.getSkillId();
            TimelineEvent ev = new TimelineEvent();
            ev.setSimulationId(simulationId);
            ev.setSequenceOrder(++order);
            ev.setSemesterLabel(null);
            ev.setEventType("SKILL_GAINED");
            ev.setDescription(skillName + " (level " + r.getLevel() + ") - no semester");
            ev.setImpactScore(r.getLevel());
            events.add(ev);
        }
        return events;
    }

    private List<CareerOutcome> buildCareerOutcomes(int studentId, int simulationId) throws SQLException {
        List<CareerOutcome> outcomes = new ArrayList<>();
        List<AcademicSnapshot> snapshots = snapshotDAO.findByStudentId(studentId);
        List<Enrollment> enrollments = enrollmentDAO.findByStudentIdAndAlternate(studentId, false);
        List<StudentSkillDAO.Row> skillRows = studentSkillDAO.findByStudentId(studentId);
        List<StudentInterestDAO.Row> interestRows = studentInterestDAO.findByStudentId(studentId);

        double avgGpa = snapshots.isEmpty() ? 0 : snapshots.stream().mapToDouble(AcademicSnapshot::getGpa).average().orElse(0);
        Map<String, Long> domainCount = new HashMap<>();
        int techCredits = 0;
        for (Enrollment e : enrollments) {
            Course c = courseDAO.findById(e.getCourseId());
            if (c != null) {
                domainCount.merge(c.getDomain(), 1L, Long::sum);
                if ("CS".equals(c.getDomain()) || "ENGINEERING".equals(c.getDomain())) techCredits += c.getCredits();
            }
        }
        long csCount = domainCount.getOrDefault("CS", 0L);
        long mathCount = domainCount.getOrDefault("MATH", 0L);
        long scienceCount = domainCount.getOrDefault("SCIENCE", 0L);
        long businessCount = domainCount.getOrDefault("BUSINESS", 0L);

        int technicalSkillLevel = 0;
        int softSkillLevel = 0;
        for (StudentSkillDAO.Row r : skillRows) {
            Skill s = skillDAO.findById(r.getSkillId());
            if (s != null) {
                if ("TECHNICAL".equals(s.getCategory())) technicalSkillLevel += r.getLevel();
                if ("SOFT".equals(s.getCategory())) softSkillLevel += r.getLevel();
            }
        }

        boolean hasResearchInterest = false;
        boolean hasDataInterest = false;
        boolean hasBusinessInterest = false;
        for (StudentInterestDAO.Row r : interestRows) {
            Interest i = interestDAO.findById(r.getInterestId());
            if (i != null) {
                String name = i.getName().toLowerCase();
                if (name.contains("research")) hasResearchInterest = true;
                if (name.contains("data") || name.contains("machine learning")) hasDataInterest = true;
                if (name.contains("business") || name.contains("consulting")) hasBusinessInterest = true;
            }
        }

        // Rule 1: Strong CS/Eng + technical skills + good GPA -> Tech roles
        if (avgGpa >= 3.0 && (csCount >= 2 || techCredits >= 12) && technicalSkillLevel >= 3) {
            CareerOutcome co = new CareerOutcome();
            co.setSimulationId(simulationId);
            co.setPredictedRole(hasDataInterest ? "Data Analyst" : "Software Engineer");
            co.setIndustry("Technology");
            co.setConfidence(Math.min(90, 60 + (int) (avgGpa * 5) + Math.min(20, technicalSkillLevel * 3)));
            co.setReasoningText("Strong technical coursework and skills with solid GPA suggest strong fit for tech roles.");
            outcomes.add(co);
        }

        // Rule 2: MATH + SCIENCE + research interest -> Research
        if ((mathCount >= 1 || scienceCount >= 1) && hasResearchInterest && avgGpa >= 3.2) {
            CareerOutcome co = new CareerOutcome();
            co.setSimulationId(simulationId);
            co.setPredictedRole("Research Scientist / Quant");
            co.setIndustry("Academia / Research / Finance");
            co.setConfidence(Math.min(85, 50 + (int) (avgGpa * 8)));
            co.setReasoningText("Math/Science background with research interest supports research or quantitative roles.");
            outcomes.add(co);
        }

        // Rule 3: BUSINESS + soft skills
        if (businessCount >= 1 && softSkillLevel >= 3) {
            CareerOutcome co = new CareerOutcome();
            co.setSimulationId(simulationId);
            co.setPredictedRole(hasBusinessInterest ? "Consultant" : "Business Analyst");
            co.setIndustry("Consulting / Business");
            co.setConfidence(Math.min(80, 45 + softSkillLevel * 8 + (int) (avgGpa * 5)));
            co.setReasoningText("Business coursework and soft skills align with analyst or consulting paths.");
            outcomes.add(co);
        }

        // Default: diverse / further education
        if (outcomes.isEmpty()) {
            CareerOutcome co = new CareerOutcome();
            co.setSimulationId(simulationId);
            co.setPredictedRole("Diverse roles / Further education");
            co.setIndustry("Various");
            co.setConfidence(Math.min(70, 30 + (int) (avgGpa * 10)));
            co.setReasoningText("Broad profile. Consider adding more courses or skills to strengthen a specific path; further education can help specialize.");
            outcomes.add(co);
        }

        return outcomes;
    }
}
