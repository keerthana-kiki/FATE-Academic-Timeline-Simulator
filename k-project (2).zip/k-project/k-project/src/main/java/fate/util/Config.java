package fate.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Loads database configuration from db.properties or environment variables.
 */
public final class Config {
    private static final String PROP_FILE = "db.properties";
    private static final String URL_KEY = "db.url";
    private static final String USER_KEY = "db.user";
    private static final String PASSWORD_KEY = "db.password";

    private static String url;
    private static String user;
    private static String password;
    private static boolean loaded;

    private Config() {}

    private static void load() {
        if (loaded) return;
        String envUrl = System.getenv("FATE_DB_URL");
        String envUser = System.getenv("FATE_DB_USER");
        String envPassword = System.getenv("FATE_DB_PASSWORD");
        if (envUrl != null && envUser != null) {
            url = envUrl;
            user = envUser;
            password = envPassword != null ? envPassword : "";
            loaded = true;
            return;
        }
        Properties p = new Properties();
        try (InputStream in = Config.class.getClassLoader().getResourceAsStream(PROP_FILE)) {
            if (in != null) {
                p.load(in);
            }
        } catch (IOException e) {
            // fallback to defaults
        }
        url = p.getProperty(URL_KEY, "jdbc:mysql://localhost:3306/fate_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC");
        user = p.getProperty(USER_KEY, "root");
        password = p.getProperty(PASSWORD_KEY, "");
        loaded = true;
    }

    public static String getDbUrl() {
        load();
        return url;
    }

    public static String getDbUser() {
        load();
        return user;
    }

    public static String getDbPassword() {
        load();
        return password;
    }
}
