package fate.util;

import java.util.Scanner;

/**
 * Console input/output helper with validation.
 */
public final class ConsoleHelper {
    private static final Scanner SCANNER = new Scanner(System.in);

    private ConsoleHelper() {}

    public static void println(String msg) {
        System.out.println(msg);
    }

    public static void print(String msg) {
        System.out.print(msg);
    }

    public static String readLine() {
        return SCANNER.nextLine().trim();
    }

    public static String readLine(String prompt) {
        print(prompt);
        return SCANNER.nextLine().trim();
    }

    /** Reads an int; re-prompts until valid. Returns value in [min, max] inclusive. */
    public static int readInt(String prompt, int min, int max) {
        while (true) {
            print(prompt);
            String line = SCANNER.nextLine().trim();
            try {
                int n = Integer.parseInt(line);
                if (n >= min && n <= max) return n;
                println("Please enter a number between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                println("Invalid number. Try again.");
            }
        }
    }

    /** Reads a double; re-prompts until valid and in [min, max]. */
    public static double readDouble(String prompt, double min, double max) {
        while (true) {
            print(prompt);
            String line = SCANNER.nextLine().trim();
            try {
                double d = Double.parseDouble(line);
                if (d >= min && d <= max) return d;
                println("Please enter a value between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                println("Invalid number. Try again.");
            }
        }
    }

    public static void close() {
        SCANNER.close();
    }
}
