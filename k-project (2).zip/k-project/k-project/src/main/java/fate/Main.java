package fate;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import fate.dao.DecisionPointDAO;
import fate.db.DatabaseConnection;
import fate.model.DecisionPoint;
import fate.model.Student;
import fate.service.SimulationEngineService;
import fate.service.StudentService;
import fate.service.TimelineDisplayService;
import fate.util.ConsoleHelper;

/**
 * FATE – Alternate Academic Timeline Simulator
 * Console entry point: menu loop and service orchestration.
 */
public class Main {
    private static Student currentStudent;
    private static final StudentService studentService = new StudentService();
    private static final SimulationEngineService simulationEngine = new SimulationEngineService(DatabaseConnection::getConnection);
    private static final TimelineDisplayService timelineDisplay = new TimelineDisplayService();
    private static final DecisionPointDAO decisionPointDAO = new DecisionPointDAO();

    public static void main(String[] args) {
        ConsoleHelper.println("FATE – Alternate Academic Timeline Simulator");
        ConsoleHelper.println("--------------------------------------------");
        runMenuLoop();
        ConsoleHelper.close();
    }

    private static void runMenuLoop() {
        while (true) {
            printMainMenu();
            int choice = ConsoleHelper.readInt("Choice: ", 1, 8);
            switch (choice) {
                case 1 -> {
                    studentService.runNewStudentFlow();
                }
                case 2 -> {
                    currentStudent = studentService.runSelectStudentFlow();
                    if (currentStudent != null) {
                        ConsoleHelper.println("Selected: " + currentStudent.getName() + " (ID " + currentStudent.getId() + ")");
                    }
                }
                case 3 -> {
                    studentService.runEnterAcademicDataFlow(currentStudent);
                }
                case 4 -> {
                    studentService.runSkillsAndInterestsFlow(currentStudent);
                }
                case 5 -> {
                    studentService.runAddDecisionPointsFlow(currentStudent);
                }
                case 6 -> {
                    runSimulationFlow();
                }
                case 7 -> {
                    viewTimelinesFlow();
                }
                case 8 -> {
                    ConsoleHelper.println("Goodbye.");
                    return;
                }
            }
        }
    }

    private static void printMainMenu() {
        ConsoleHelper.println("");
        ConsoleHelper.println("--- Main Menu ---");
        ConsoleHelper.println("1. New Student");
        ConsoleHelper.println("2. Select Student");
        ConsoleHelper.println("3. Enter Academic Data");
        ConsoleHelper.println("4. Enter Skills and Interests");
        ConsoleHelper.println("5. Add Decision Points");
        ConsoleHelper.println("6. Run Simulation");
        ConsoleHelper.println("7. View Timelines and Outcomes");
        ConsoleHelper.println("8. Exit");
    }

    private static void runSimulationFlow() {
        if (currentStudent == null) {
            ConsoleHelper.println("Please select a student first (option 2).");
            return;
        }
        ConsoleHelper.println("1. Base timeline (current data)");
        ConsoleHelper.println("2. What-if scenario (override a decision)");
        int sub = ConsoleHelper.readInt("Choice: ", 1, 2);
        String name = ConsoleHelper.readLine("Simulation name: ");
        if (name.isEmpty()) name = "Base timeline";
        String note = ConsoleHelper.readLine("Scenario note (optional): ");

        if (sub == 1) {
            var sim = simulationEngine.runBaseSimulation(currentStudent.getId(), name, note);
            if (sim != null) ConsoleHelper.println("Simulation created with ID: " + sim.getId());
        } else {
            try {
                List<DecisionPoint> decisions = decisionPointDAO.findByStudentId(currentStudent.getId());
                if (decisions.isEmpty()) {
                    ConsoleHelper.println("No decision points found. Add some first (option 5). Running as base.");
                    var sim = simulationEngine.runBaseSimulation(currentStudent.getId(), name, note);
                    if (sim != null) ConsoleHelper.println("Simulation created with ID: " + sim.getId());
                    return;
                }
                ConsoleHelper.println("Decision points:");
                for (DecisionPoint dp : decisions) {
                    ConsoleHelper.println("  " + dp.getId() + ": " + dp.getSemesterLabel() + " - " + dp.getDecisionType() + " (" + Objects.toString(dp.getChoiceDetail(), "(no detail)") + ")");
                }
                int dpId = ConsoleHelper.readInt("Decision point ID to override (0 = none, run base): ", 0, 9999);
                Map<Integer, String> overrides = new HashMap<>();
                if (dpId != 0) {
                    String alt = ConsoleHelper.readLine("Alternate choice (what-if): ");
                    if (!alt.isEmpty()) overrides.put(dpId, alt);
                }
                var sim = simulationEngine.runSimulation(currentStudent.getId(), name, note, overrides);
                if (sim != null) ConsoleHelper.println("Simulation created with ID: " + sim.getId());
            } catch (SQLException e) {
                ConsoleHelper.println("Database error: " + e.getMessage());
            }
        }
    }

    private static void viewTimelinesFlow() {
        if (currentStudent == null) {
            ConsoleHelper.println("Please select a student first (option 2).");
            return;
        }
        timelineDisplay.listSimulationsForStudent(currentStudent.getId());
        int simId = ConsoleHelper.readInt("Enter simulation ID to view (0 to back): ", 0, 99999);
        if (simId != 0) {
            timelineDisplay.showSimulationDetail(simId);
        }
    }
}
