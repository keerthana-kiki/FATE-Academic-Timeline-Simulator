package fate.dao;

import fate.db.DatabaseConnection;
import fate.model.Enrollment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAO {

    public int insert(Enrollment e) throws SQLException {
        String sql = "INSERT INTO enrollments (student_id, course_id, semester_label, grade, is_alternate) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, e.getStudentId());
            ps.setInt(2, e.getCourseId());
            ps.setString(3, e.getSemesterLabel());
            ps.setString(4, e.getGrade());
            ps.setBoolean(5, e.isAlternate());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    e.setId(id);
                    return id;
                }
            }
        }
        return -1;
    }

    public List<Enrollment> findByStudentId(int studentId) throws SQLException {
        String sql = "SELECT id, student_id, course_id, semester_label, grade, is_alternate, created_at FROM enrollments WHERE student_id = ? ORDER BY semester_label, course_id";
        List<Enrollment> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    public List<Enrollment> findByStudentIdAndAlternate(int studentId, boolean isAlternate) throws SQLException {
        String sql = "SELECT id, student_id, course_id, semester_label, grade, is_alternate, created_at FROM enrollments WHERE student_id = ? AND is_alternate = ? ORDER BY semester_label, course_id";
        List<Enrollment> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setBoolean(2, isAlternate);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    private static Enrollment mapRow(ResultSet rs) throws SQLException {
        Enrollment e = new Enrollment();
        e.setId(rs.getInt("id"));
        e.setStudentId(rs.getInt("student_id"));
        e.setCourseId(rs.getInt("course_id"));
        e.setSemesterLabel(rs.getString("semester_label"));
        e.setGrade(rs.getString("grade"));
        e.setAlternate(rs.getBoolean("is_alternate"));
        Timestamp ts = rs.getTimestamp("created_at");
        e.setCreatedAt(ts != null ? ts.toLocalDateTime() : null);
        return e;
    }
}
