package fate.dao;

import fate.db.DatabaseConnection;
import fate.model.CareerOutcome;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CareerOutcomeDAO {

    public int insert(CareerOutcome c) throws SQLException {
        String sql = "INSERT INTO career_outcomes (simulation_id, predicted_role, industry, confidence, reasoning_text) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, c.getSimulationId());
            ps.setString(2, c.getPredictedRole());
            ps.setString(3, c.getIndustry());
            ps.setInt(4, c.getConfidence());
            ps.setString(5, c.getReasoningText());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    c.setId(id);
                    return id;
                }
            }
        }
        return -1;
    }

    public int insert(Connection conn, CareerOutcome c) throws SQLException {
        String sql = "INSERT INTO career_outcomes (simulation_id, predicted_role, industry, confidence, reasoning_text) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, c.getSimulationId());
            ps.setString(2, c.getPredictedRole());
            ps.setString(3, c.getIndustry());
            ps.setInt(4, c.getConfidence());
            ps.setString(5, c.getReasoningText());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    c.setId(id);
                    return id;
                }
            }
        }
        return -1;
    }

    public List<CareerOutcome> findBySimulationId(int simulationId) throws SQLException {
        String sql = "SELECT id, simulation_id, predicted_role, industry, confidence, reasoning_text, created_at FROM career_outcomes WHERE simulation_id = ? ORDER BY confidence DESC";
        List<CareerOutcome> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, simulationId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    private static CareerOutcome mapRow(ResultSet rs) throws SQLException {
        CareerOutcome c = new CareerOutcome();
        c.setId(rs.getInt("id"));
        c.setSimulationId(rs.getInt("simulation_id"));
        c.setPredictedRole(rs.getString("predicted_role"));
        c.setIndustry(rs.getString("industry"));
        c.setConfidence(rs.getInt("confidence"));
        c.setReasoningText(rs.getString("reasoning_text"));
        Timestamp ts = rs.getTimestamp("created_at");
        c.setCreatedAt(ts != null ? ts.toLocalDateTime() : null);
        return c;
    }
}
