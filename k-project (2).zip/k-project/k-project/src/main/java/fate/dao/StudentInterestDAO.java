package fate.dao;

import fate.db.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO for student_interests link table.
 */
public class StudentInterestDAO {

    public static class Row {
        private final int interestId;
        private final int strength;

        public Row(int interestId, int strength) {
            this.interestId = interestId;
            this.strength = strength;
        }
        public int getInterestId() { return interestId; }
        public int getStrength() { return strength; }
    }

    public void insert(int studentId, int interestId, int strength) throws SQLException {
        String sql = "INSERT INTO student_interests (student_id, interest_id, strength) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE strength = VALUES(strength)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, interestId);
            ps.setInt(3, strength);
            ps.executeUpdate();
        }
    }

    public List<Row> findByStudentId(int studentId) throws SQLException {
        String sql = "SELECT interest_id, strength FROM student_interests WHERE student_id = ?";
        List<Row> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Row(rs.getInt("interest_id"), rs.getInt("strength")));
                }
            }
        }
        return list;
    }
}
