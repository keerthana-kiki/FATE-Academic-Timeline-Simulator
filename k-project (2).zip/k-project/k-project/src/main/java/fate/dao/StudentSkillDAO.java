package fate.dao;

import fate.db.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO for student_skills link table.
 * Use SkillDAO to resolve skill id to Skill entity.
 */
public class StudentSkillDAO {

    public static class Row {
        private final int skillId;
        private final int level;
        private final String semesterAcquired;

        public Row(int skillId, int level, String semesterAcquired) {
            this.skillId = skillId;
            this.level = level;
            this.semesterAcquired = semesterAcquired;
        }
        public int getSkillId() { return skillId; }
        public int getLevel() { return level; }
        public String getSemesterAcquired() { return semesterAcquired; }
    }

    public void insert(int studentId, int skillId, int level, String semesterAcquired) throws SQLException {
        String sql = "INSERT INTO student_skills (student_id, skill_id, level, semester_acquired) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE level = VALUES(level), semester_acquired = VALUES(semester_acquired)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, skillId);
            ps.setInt(3, level);
            ps.setString(4, semesterAcquired);
            ps.executeUpdate();
        }
    }

    public List<Row> findByStudentId(int studentId) throws SQLException {
        String sql = "SELECT skill_id, level, semester_acquired FROM student_skills WHERE student_id = ? ORDER BY semester_acquired, skill_id";
        List<Row> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Row(rs.getInt("skill_id"), rs.getInt("level"), rs.getString("semester_acquired")));
                }
            }
        }
        return list;
    }
}
