package fate.dao;

import fate.db.DatabaseConnection;
import fate.model.Simulation;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SimulationDAO {

    public int insert(Simulation s) throws SQLException {
        String sql = "INSERT INTO simulations (student_id, name, scenario_note) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, s.getStudentId());
            ps.setString(2, s.getName());
            ps.setString(3, s.getScenarioNote());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    s.setId(id);
                    return id;
                }
            }
        }
        return -1;
    }

    public int insert(Connection conn, Simulation s) throws SQLException {
        String sql = "INSERT INTO simulations (student_id, name, scenario_note) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, s.getStudentId());
            ps.setString(2, s.getName());
            ps.setString(3, s.getScenarioNote());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    s.setId(id);
                    return id;
                }
            }
        }
        return -1;
    }

    public Simulation findById(int id) throws SQLException {
        String sql = "SELECT id, student_id, name, scenario_note, created_at FROM simulations WHERE id = ?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public List<Simulation> findByStudentId(int studentId) throws SQLException {
        String sql = "SELECT id, student_id, name, scenario_note, created_at FROM simulations WHERE student_id = ? ORDER BY created_at DESC";
        List<Simulation> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    private static Simulation mapRow(ResultSet rs) throws SQLException {
        Simulation s = new Simulation();
        s.setId(rs.getInt("id"));
        s.setStudentId(rs.getInt("student_id"));
        s.setName(rs.getString("name"));
        s.setScenarioNote(rs.getString("scenario_note"));
        Timestamp ts = rs.getTimestamp("created_at");
        s.setCreatedAt(ts != null ? ts.toLocalDateTime() : null);
        return s;
    }
}
