package fate.dao;

import fate.db.DatabaseConnection;
import fate.model.Interest;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InterestDAO {

    public Interest findById(int id) throws SQLException {
        String sql = "SELECT id, name FROM interests WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public List<Interest> findAll() throws SQLException {
        String sql = "SELECT id, name FROM interests ORDER BY name";
        List<Interest> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    private static Interest mapRow(ResultSet rs) throws SQLException {
        Interest i = new Interest();
        i.setId(rs.getInt("id"));
        i.setName(rs.getString("name"));
        return i;
    }
}
