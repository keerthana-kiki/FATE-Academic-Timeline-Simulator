package fate.dao;

import fate.db.DatabaseConnection;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Stores alternate choices for decision points in a simulation (what-if overrides).
 */
public class SimulationDecisionDAO {

    public void insert(int simulationId, int decisionPointId, String alternateChoice) throws SQLException {
        String sql = "INSERT INTO simulation_decisions (simulation_id, decision_point_id, alternate_choice) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE alternate_choice = VALUES(alternate_choice)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, simulationId);
            ps.setInt(2, decisionPointId);
            ps.setString(3, alternateChoice);
            ps.executeUpdate();
        }
    }

    public void insert(Connection conn, int simulationId, int decisionPointId, String alternateChoice) throws SQLException {
        String sql = "INSERT INTO simulation_decisions (simulation_id, decision_point_id, alternate_choice) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE alternate_choice = VALUES(alternate_choice)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, simulationId);
            ps.setInt(2, decisionPointId);
            ps.setString(3, alternateChoice);
            ps.executeUpdate();
        }
    }

    /** Returns map: decision_point_id -> alternate_choice (null if use original). */
    public Map<Integer, String> getAlternateChoicesBySimulationId(int simulationId) throws SQLException {
        String sql = "SELECT decision_point_id, alternate_choice FROM simulation_decisions WHERE simulation_id = ?";
        Map<Integer, String> map = new HashMap<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, simulationId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    map.put(rs.getInt("decision_point_id"), rs.getString("alternate_choice"));
                }
            }
        }
        return map;
    }
}
