package fate.dao;

import fate.db.DatabaseConnection;
import fate.model.Course;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {

    public Course findById(int id) throws SQLException {
        String sql = "SELECT id, code, name, category, credits, domain FROM courses WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public List<Course> findAll() throws SQLException {
        String sql = "SELECT id, code, name, category, credits, domain FROM courses ORDER BY code";
        List<Course> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    private static Course mapRow(ResultSet rs) throws SQLException {
        Course c = new Course();
        c.setId(rs.getInt("id"));
        c.setCode(rs.getString("code"));
        c.setName(rs.getString("name"));
        c.setCategory(rs.getString("category"));
        c.setCredits(rs.getInt("credits"));
        c.setDomain(rs.getString("domain"));
        return c;
    }
}
