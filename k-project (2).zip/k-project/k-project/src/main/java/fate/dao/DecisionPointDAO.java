package fate.dao;

import fate.db.DatabaseConnection;
import fate.model.DecisionPoint;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DecisionPointDAO {

    public int insert(DecisionPoint d) throws SQLException {
        String sql = "INSERT INTO decision_points (student_id, semester_label, decision_type, choice_detail, impact_weight) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, d.getStudentId());
            ps.setString(2, d.getSemesterLabel());
            ps.setString(3, d.getDecisionType());
            ps.setString(4, d.getChoiceDetail());
            ps.setInt(5, d.getImpactWeight());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    d.setId(id);
                    return id;
                }
            }
        }
        return -1;
    }

    public List<DecisionPoint> findByStudentId(int studentId) throws SQLException {
        String sql = "SELECT id, student_id, semester_label, decision_type, choice_detail, impact_weight, created_at FROM decision_points WHERE student_id = ? ORDER BY semester_label";
        List<DecisionPoint> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    public DecisionPoint findById(int id) throws SQLException {
        String sql = "SELECT id, student_id, semester_label, decision_type, choice_detail, impact_weight, created_at FROM decision_points WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    private static DecisionPoint mapRow(ResultSet rs) throws SQLException {
        DecisionPoint d = new DecisionPoint();
        d.setId(rs.getInt("id"));
        d.setStudentId(rs.getInt("student_id"));
        d.setSemesterLabel(rs.getString("semester_label"));
        d.setDecisionType(rs.getString("decision_type"));
        d.setChoiceDetail(rs.getString("choice_detail"));
        d.setImpactWeight(rs.getInt("impact_weight"));
        Timestamp ts = rs.getTimestamp("created_at");
        d.setCreatedAt(ts != null ? ts.toLocalDateTime() : null);
        return d;
    }
}
