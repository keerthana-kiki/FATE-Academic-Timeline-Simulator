package fate.dao;

import fate.db.DatabaseConnection;
import fate.model.TimelineEvent;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TimelineEventDAO {

    public int insert(TimelineEvent e) throws SQLException {
        String sql = "INSERT INTO timeline_events (simulation_id, sequence_order, semester_label, event_type, description, impact_score) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, e.getSimulationId());
            ps.setInt(2, e.getSequenceOrder());
            ps.setString(3, e.getSemesterLabel());
            ps.setString(4, e.getEventType());
            ps.setString(5, e.getDescription());
            if (e.getImpactScore() != null) ps.setInt(6, e.getImpactScore()); else ps.setNull(6, Types.TINYINT);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    e.setId(id);
                    return id;
                }
            }
        }
        return -1;
    }

    public int insert(Connection conn, TimelineEvent e) throws SQLException {
        String sql = "INSERT INTO timeline_events (simulation_id, sequence_order, semester_label, event_type, description, impact_score) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, e.getSimulationId());
            ps.setInt(2, e.getSequenceOrder());
            ps.setString(3, e.getSemesterLabel());
            ps.setString(4, e.getEventType());
            ps.setString(5, e.getDescription());
            if (e.getImpactScore() != null) ps.setInt(6, e.getImpactScore()); else ps.setNull(6, Types.TINYINT);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    e.setId(id);
                    return id;
                }
            }
        }
        return -1;
    }

    public List<TimelineEvent> findBySimulationId(int simulationId) throws SQLException {
        String sql = "SELECT id, simulation_id, sequence_order, semester_label, event_type, description, impact_score, created_at FROM timeline_events WHERE simulation_id = ? ORDER BY sequence_order";
        List<TimelineEvent> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, simulationId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    private static TimelineEvent mapRow(ResultSet rs) throws SQLException {
        TimelineEvent e = new TimelineEvent();
        e.setId(rs.getInt("id"));
        e.setSimulationId(rs.getInt("simulation_id"));
        e.setSequenceOrder(rs.getInt("sequence_order"));
        e.setSemesterLabel(rs.getString("semester_label"));
        e.setEventType(rs.getString("event_type"));
        e.setDescription(rs.getString("description"));
        int impact = rs.getInt("impact_score");
        e.setImpactScore(rs.wasNull() ? null : impact);
        Timestamp ts = rs.getTimestamp("created_at");
        e.setCreatedAt(ts != null ? ts.toLocalDateTime() : null);
        return e;
    }
}
