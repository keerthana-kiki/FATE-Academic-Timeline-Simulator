package fate.dao;

import fate.db.DatabaseConnection;
import fate.model.AcademicSnapshot;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AcademicSnapshotDAO {

    public int insert(AcademicSnapshot a) throws SQLException {
        String sql = "INSERT INTO academic_snapshots (student_id, semester_label, gpa, total_credits, standing) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, a.getStudentId());
            ps.setString(2, a.getSemesterLabel());
            ps.setDouble(3, a.getGpa());
            ps.setInt(4, a.getTotalCredits());
            ps.setString(5, a.getStanding());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    a.setId(id);
                    return id;
                }
            }
        }
        return -1;
    }

    public List<AcademicSnapshot> findByStudentId(int studentId) throws SQLException {
        String sql = "SELECT id, student_id, semester_label, gpa, total_credits, standing, created_at FROM academic_snapshots WHERE student_id = ? ORDER BY semester_label";
        List<AcademicSnapshot> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    private static AcademicSnapshot mapRow(ResultSet rs) throws SQLException {
        AcademicSnapshot a = new AcademicSnapshot();
        a.setId(rs.getInt("id"));
        a.setStudentId(rs.getInt("student_id"));
        a.setSemesterLabel(rs.getString("semester_label"));
        a.setGpa(rs.getDouble("gpa"));
        a.setTotalCredits(rs.getInt("total_credits"));
        a.setStanding(rs.getString("standing"));
        Timestamp ts = rs.getTimestamp("created_at");
        a.setCreatedAt(ts != null ? ts.toLocalDateTime() : null);
        return a;
    }
}
