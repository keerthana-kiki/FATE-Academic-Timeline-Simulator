package fate.model;

import java.time.LocalDateTime;

public class DecisionPoint {
    private int id;
    private int studentId;
    private String semesterLabel;
    private String decisionType;
    private String choiceDetail;
    private int impactWeight;
    private LocalDateTime createdAt;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
    public String getSemesterLabel() { return semesterLabel; }
    public void setSemesterLabel(String semesterLabel) { this.semesterLabel = semesterLabel; }
    public String getDecisionType() { return decisionType; }
    public void setDecisionType(String decisionType) { this.decisionType = decisionType; }
    public String getChoiceDetail() { return choiceDetail; }
    public void setChoiceDetail(String choiceDetail) { this.choiceDetail = choiceDetail; }
    public int getImpactWeight() { return impactWeight; }
    public void setImpactWeight(int impactWeight) { this.impactWeight = impactWeight; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
