package fate.model;

import java.time.LocalDateTime;

public class Simulation {
    private int id;
    private int studentId;
    private String name;
    private String scenarioNote;
    private LocalDateTime createdAt;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getScenarioNote() { return scenarioNote; }
    public void setScenarioNote(String scenarioNote) { this.scenarioNote = scenarioNote; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
