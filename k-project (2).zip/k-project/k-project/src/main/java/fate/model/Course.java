package fate.model;

public class Course {
    private int id;
    private String code;
    private String name;
    private String category;
    private int credits;
    private String domain;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }
    public String getDomain() { return domain; }
    public void setDomain(String domain) { this.domain = domain; }
}
