package fate.model;

import java.time.LocalDateTime;

public class CareerOutcome {
    private int id;
    private int simulationId;
    private String predictedRole;
    private String industry;
    private int confidence;
    private String reasoningText;
    private LocalDateTime createdAt;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getSimulationId() { return simulationId; }
    public void setSimulationId(int simulationId) { this.simulationId = simulationId; }
    public String getPredictedRole() { return predictedRole; }
    public void setPredictedRole(String predictedRole) { this.predictedRole = predictedRole; }
    public String getIndustry() { return industry; }
    public void setIndustry(String industry) { this.industry = industry; }
    public int getConfidence() { return confidence; }
    public void setConfidence(int confidence) { this.confidence = confidence; }
    public String getReasoningText() { return reasoningText; }
    public void setReasoningText(String reasoningText) { this.reasoningText = reasoningText; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
