package fate.db;

import fate.util.Config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Provides JDBC connections for the FATE application.
 * Uses Config for URL, user, and password.
 * Falls back to H2 in-memory database if MySQL is unavailable.
 */
public final class DatabaseConnection {
    private static final String MYSQL_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String H2_DRIVER = "org.h2.Driver";
    private static boolean useH2 = false;
    private static boolean schemaInitialized = false;

    static {
        try {
            Class.forName(MYSQL_DRIVER);
        } catch (ClassNotFoundException e) {
            // MySQL driver not available, will try H2
            try {
                Class.forName(H2_DRIVER);
                useH2 = true;
                System.out.println("MySQL JDBC driver not found. Using H2 database instead.");
            } catch (ClassNotFoundException e2) {
                throw new RuntimeException("No database driver available. Add mysql-connector-j or h2 to classpath.", e2);
            }
        }
    }

    private DatabaseConnection() {}

    public static Connection getConnection() throws SQLException {
        if (useH2) {
            return getH2Connection();
        }
        
        try {
            return DriverManager.getConnection(
                    Config.getDbUrl(),
                    Config.getDbUser(),
                    Config.getDbPassword()
            );
        } catch (SQLException e) {
            // Fall back to H2 if MySQL connection fails
            System.out.println("MySQL connection failed: " + e.getMessage() + ". Falling back to H2 database.");
            useH2 = true;
            return getH2Connection();
        }
    }

    private static Connection getH2Connection() throws SQLException {
        Connection conn = DriverManager.getConnection(
                "jdbc:h2:mem:fate_db;DB_CLOSE_DELAY=-1",
                "sa",
                ""
        );
        
        // Initialize schema if not already done
        if (!schemaInitialized) {
            initializeH2Schema(conn);
            schemaInitialized = true;
        }
        
        return conn;
    }

    private static void initializeH2Schema(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            // Drop existing tables if they exist
            stmt.execute("DROP TABLE IF EXISTS timeline_events");
            stmt.execute("DROP TABLE IF EXISTS simulation_decisions");
            stmt.execute("DROP TABLE IF EXISTS career_outcomes");
            stmt.execute("DROP TABLE IF EXISTS simulations");
            stmt.execute("DROP TABLE IF EXISTS student_interests");
            stmt.execute("DROP TABLE IF EXISTS student_skills");
            stmt.execute("DROP TABLE IF EXISTS enrollments");
            stmt.execute("DROP TABLE IF EXISTS academic_snapshots");
            stmt.execute("DROP TABLE IF EXISTS students");
            stmt.execute("DROP TABLE IF EXISTS interests");
            stmt.execute("DROP TABLE IF EXISTS skills");
            stmt.execute("DROP TABLE IF EXISTS courses");

            // Create tables
            stmt.execute("""
                CREATE TABLE courses (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    code VARCHAR(20) NOT NULL UNIQUE,
                    name VARCHAR(100) NOT NULL,
                    category VARCHAR(20) NOT NULL DEFAULT 'ELECTIVE',
                    credits INT NOT NULL DEFAULT 3,
                    domain VARCHAR(20) NOT NULL DEFAULT 'CS'
                )
                """);

            stmt.execute("""
                CREATE TABLE skills (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(80) NOT NULL,
                    category VARCHAR(20) NOT NULL DEFAULT 'TECHNICAL'
                )
                """);

            stmt.execute("""
                CREATE TABLE interests (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(80) NOT NULL
                )
                """);

            stmt.execute("""
                CREATE TABLE students (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    email VARCHAR(120) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """);

            stmt.execute("""
                CREATE TABLE academic_snapshots (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    semester_label VARCHAR(20) NOT NULL,
                    gpa DECIMAL(3,2) NOT NULL,
                    total_credits INT NOT NULL DEFAULT 0,
                    standing VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
                    FOREIGN KEY (student_id) REFERENCES students(id)
                )
                """);

            stmt.execute("""
                CREATE TABLE enrollments (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    course_id INT NOT NULL,
                    semester_label VARCHAR(20) NOT NULL,
                    grade VARCHAR(2) NOT NULL,
                    is_alternate BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (student_id) REFERENCES students(id),
                    FOREIGN KEY (course_id) REFERENCES courses(id)
                )
                """);

            stmt.execute("""
                CREATE TABLE decision_points (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    semester_label VARCHAR(20) NOT NULL,
                    decision_type VARCHAR(50) NOT NULL,
                    choice_detail VARCHAR(200),
                    impact_weight INT NOT NULL DEFAULT 5,
                    FOREIGN KEY (student_id) REFERENCES students(id)
                )
                """);

            stmt.execute("""
                CREATE TABLE student_skills (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    skill_id INT NOT NULL,
                    level INT NOT NULL DEFAULT 1,
                    FOREIGN KEY (student_id) REFERENCES students(id),
                    FOREIGN KEY (skill_id) REFERENCES skills(id)
                )
                """);

            stmt.execute("""
                CREATE TABLE student_interests (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    interest_id INT NOT NULL,
                    strength INT NOT NULL DEFAULT 3,
                    FOREIGN KEY (student_id) REFERENCES students(id),
                    FOREIGN KEY (interest_id) REFERENCES interests(id)
                )
                """);

            stmt.execute("""
                CREATE TABLE simulations (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    name VARCHAR(100) NOT NULL,
                    scenario_note TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (student_id) REFERENCES students(id)
                )
                """);

            stmt.execute("""
                CREATE TABLE simulation_decisions (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    simulation_id INT NOT NULL,
                    decision_point_id INT NOT NULL,
                    alternate_choice VARCHAR(200),
                    FOREIGN KEY (simulation_id) REFERENCES simulations(id),
                    FOREIGN KEY (decision_point_id) REFERENCES decision_points(id)
                )
                """);

            stmt.execute("""
                CREATE TABLE timeline_events (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    simulation_id INT NOT NULL,
                    sequence_order INT NOT NULL,
                    semester_label VARCHAR(20) NOT NULL,
                    event_type VARCHAR(50) NOT NULL,
                    description TEXT,
                    impact_score TINYINT,
                    FOREIGN KEY (simulation_id) REFERENCES simulations(id)
                )
                """);

            stmt.execute("""
                CREATE TABLE career_outcomes (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    simulation_id INT NOT NULL,
                    predicted_role VARCHAR(100) NOT NULL,
                    industry VARCHAR(100),
                    confidence INT NOT NULL DEFAULT 50,
                    reasoning_text TEXT,
                    FOREIGN KEY (simulation_id) REFERENCES simulations(id)
                )
                """);

            // Insert sample data
            stmt.execute("INSERT INTO courses (code, name, domain) VALUES ('CS101', 'Intro to CS', 'CS')");
            stmt.execute("INSERT INTO courses (code, name, domain) VALUES ('CS201', 'Data Structures', 'CS')");
            stmt.execute("INSERT INTO courses (code, name, domain) VALUES ('MATH101', 'Calculus I', 'MATH')");
            stmt.execute("INSERT INTO courses (code, name, domain) VALUES ('ENG101', 'Circuits', 'ENGINEERING')");
            
            stmt.execute("INSERT INTO skills (name, category) VALUES ('Problem Solving', 'TECHNICAL')");
            stmt.execute("INSERT INTO skills (name, category) VALUES ('Communication', 'SOFT')");
            stmt.execute("INSERT INTO skills (name, category) VALUES ('Programming', 'TECHNICAL')");
            
            stmt.execute("INSERT INTO interests (name) VALUES ('Software Development')");
            stmt.execute("INSERT INTO interests (name) VALUES ('Data Science')");
            stmt.execute("INSERT INTO interests (name) VALUES ('Web Development')");
            
            conn.commit();
        }
    }
}

