# FATE – Alternate Academic Timeline Simulator

A Java console-based application that simulates different academic timelines based on student decisions, performance, courses, skills, and interests. It uses **JDBC** for persistence and rule-based logic to generate timeline events and career outcome predictions.

## Features

- **Student management**: Create and select students
- **Academic data**: Record semesters (GPA, credits, standing) and course enrollments with grades
- **Skills and interests**: Link students to skills (with level 1–5) and interests (with strength 1–5)
- **Decision points**: Log key decisions (e.g. specialization switch, skill focus, course drop) with impact weight
- **Simulations**: Run a **base timeline** from actual data, or **what-if** scenarios by overriding a decision’s choice
- **Timeline events**: Generated events include courses taken, skills gained, decisions made, and milestones (e.g. Dean’s List)
- **Career outcomes**: Rule-based predictions (e.g. Software Engineer, Data Analyst, Research Scientist, Business Analyst) with confidence and reasoning

## Prerequisites

- **Java 11** or later
- **MySQL** (or compatible server) with a database for FATE
- **Maven** 3.6+

## Database setup

1. Create the database and tables by running the schema script:

   ```bash
   mysql -u root -p < schema.sql
   ```

   Or open `schema.sql` in MySQL Workbench / your client and execute it. It creates the database `fate_db`, all tables, and seed data (courses, skills, interests).

2. Configure connection settings in one of these ways:

   - **Option A – `db.properties`**  
     Edit `src/main/resources/db.properties`:

     ```properties
     db.url=jdbc:mysql://localhost:3306/fate_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
     db.user=root
     db.password=YOUR_PASSWORD
     ```

   - **Option B – Environment variables**

     - `FATE_DB_URL` – JDBC URL  
     - `FATE_DB_USER` – username  
     - `FATE_DB_PASSWORD` – password  

## Build and run

From the project root (`k-project`):

```bash
mvn compile exec:java
```

Or compile and run the JAR with classpath:

```bash
mvn package
java -cp "target/fate-simulator-1.0.0.jar;target/lib/*" fate.Main
```

On Linux/macOS use `:` instead of `;` in the classpath.

## Usage flow

1. **New Student** – Enter name and email to create a student.
2. **Select Student** – Choose the active student by ID.
3. **Enter Academic Data** – Add a semester (label, GPA, credits, standing) and enrollments (course ID, grade) from the seeded course list.
4. **Enter Skills and Interests** – Add skills and interests for the current student (use IDs from the seeded lists).
5. **Add Decision Points** – Record a decision (semester, type, choice detail, impact weight).
6. **Run Simulation** – Create a **base** timeline or a **what-if** scenario (override one decision). Enter a simulation name and optional note.
7. **View Timelines and Outcomes** – List simulations for the current student and view a simulation’s timeline events and career outcomes.
8. **Exit** – Quit the application.

## Project structure

- `schema.sql` – Database creation and seed data
- `src/main/java/fate/`
  - `Main.java` – Entry point and menu loop
  - `db/DatabaseConnection.java` – JDBC connection provider
  - `util/Config.java`, `ConsoleHelper.java` – Config and console I/O
  - `model/` – POJOs for students, courses, enrollments, simulations, etc.
  - `dao/` – JDBC DAOs for all entities
  - `service/StudentService.java` – Student and data-entry flows
  - `service/SimulationEngineService.java` – Timeline and career outcome generation
  - `service/TimelineDisplayService.java` – Console display of timelines and outcomes
- `src/main/resources/db.properties` – Default DB configuration

## License

This project is for educational use.
