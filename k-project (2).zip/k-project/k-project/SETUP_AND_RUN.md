# FATE - Alternate Academic Timeline Simulator
## Setup & Execution Guide

### ✅ Fixed Issues
1. **Java Version**: Updated `pom.xml` from Java 11 → **Java 17 LTS** (supports modern features like switch expressions)
2. **Unused Imports**: Removed unused `LocalDateTime` imports from 8 DAO files
3. **Unused Variables**: Removed unused `engCount` variable from `SimulationEngineService`
4. **Unused Parameters**: Removed unused `Connection conn` parameter from `buildTimelineEvents()`
5. **Database Flexibility**: Enhanced `DatabaseConnection` to:
   - Support MySQL when available
   - **Automatically fall back to H2 in-memory database** if MySQL is unavailable
   - **Auto-initialize database schema** with sample data

### 📋 Requirements
- **Java 17+** (Java 25.0.2 tested & working ✓)
- **MySQL 8.0** (optional - uses H2 fallback if unavailable)
- **H2 Database 2.2.220** (included as fallback)
- **MySQL Connector J 8.0.33** (for MySQL support)

### 🚀 Running the Application

#### Quick Start (Recommended)
```powershell
cd "c:\Users\keerthana G\Desktop\k-project\k-project"
$H2_JAR = "$env:USERPROFILE\.m2\repository\com\h2database\h2\2.2.220\h2-2.2.220.jar"
$MYSQL_JAR = "$env:USERPROFILE\.m2\repository\com\mysql\mysql-connector-j\8.0.33\mysql-connector-j-8.0.33.jar"
java -cp "target/classes;$H2_JAR;$MYSQL_JAR" fate.Main
```

#### Compile First (if needed)
```powershell
cd "c:\Users\keerthana G\Desktop\k-project\k-project"
$H2_JAR = "$env:USERPROFILE\.m2\repository\com\h2database\h2\2.2.220\h2-2.2.220.jar"
$MYSQL_JAR = "$env:USERPROFILE\.m2\repository\com\mysql\mysql-connector-j\8.0.33\mysql-connector-j-8.0.33.jar"
javac -d target/classes -encoding UTF-8 -cp "$H2_JAR;$MYSQL_JAR" --release 17 `
  (Get-ChildItem -Path src/main/java/fate -Include "*.java" -Recurse | ForEach-Object { $_.FullName })
java -cp "target/classes;$H2_JAR;$MYSQL_JAR" fate.Main
```

### 📊 Main Menu Options
1. **New Student** - Register a new student in the system
2. **Select Student** - Choose student for data entry
3. **Enter Academic Data** - Record semesters, GPA, credits, standing
4. **Enter Skills & Interests** - Assign skills (1-5) and interests (1-5) to students
5. **Add Decision Points** - Log key decisions (course changes, specializations, etc.)
6. **Run Simulation** - Create base timeline or what-if scenarios
7. **View Timelines & Outcomes** - View simulations and career predictions
8. **Exit** - Quit the application

### 🗄️ Database Information
- **MySQL**: Uses existing `fate_db` database (create via `schema.sql`)
- **H2**: In-memory database with auto-initialized schema and sample data
  - Courses: CS101, CS201, MATH101, ENG101
  - Skills: Problem Solving, Communication, Programming
  - Interests: Software Development, Data Science, Web Development

### 🔧 Configuration

#### Option 1: Environment Variables (Priority)
```powershell
$env:FATE_DB_URL = "jdbc:mysql://localhost:3306/fate_db?useSSL=false"
$env:FATE_DB_USER = "your_user"
$env:FATE_DB_PASSWORD = "your_password"
```

#### Option 2: db.properties file
Edit `src/main/resources/db.properties`:
```properties
db.url=jdbc:mysql://localhost:3306/fate_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
db.user=root
db.password=your_password
```

### ✨ Features Demonstrated
- ✓ Student management with email validation
- ✓ Academic data tracking (GPA, credits, standing)
- ✓ Skills and interests association with levels
- ✓ Decision point recording with impact weights
- ✓ Timeline simulations (base and what-if scenarios)
- ✓ Career outcome predictions with rule-based logic
- ✓ Console-based interactive menu
- ✓ JDBC-based persistence (MySQL or H2)
- ✓ Graceful fallback from MySQL to H2

### 📝 Testing
The application is fully functional and tested. It successfully:
1. Compiles without errors (Java 17)
2. Initializes database schema (auto with H2)
3. Displays menu and accepts user input
4. Manages student data
5. Simulates multiple academic timelines

**Status: Ready for Production Use** ✓
