#!/usr/bin/env pwsh
<#
FATE - Alternate Academic Timeline Simulator
Quick Run Script (PowerShell)
#>

# Set paths
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$H2JAR = "$env:USERPROFILE\.m2\repository\com\h2database\h2\2.2.220\h2-2.2.220.jar"
$MYSQL_JAR = "$env:USERPROFILE\.m2\repository\com\mysql\mysql-connector-j\8.0.33\mysql-connector-j-8.0.33.jar"

# Check if JARs exist
if (-not (Test-Path $H2JAR)) {
    Write-Host "Error: H2 JAR not found at $H2JAR" -ForegroundColor Red
    Write-Host "Please download Maven dependencies: mvn dependency:resolve" -ForegroundColor Yellow
    exit 1
}

if (-not (Test-Path $MYSQL_JAR)) {
    Write-Host "Error: MySQL JAR not found at $MYSQL_JAR" -ForegroundColor Red
    Write-Host "Please download Maven dependencies: mvn dependency:resolve" -ForegroundColor Yellow
    exit 1
}

# Check if compiled
if (-not (Test-Path "$ProjectDir\target\classes\fate\Main.class")) {
    Write-Host "Application not compiled. Compiling now..." -ForegroundColor Yellow
    
    Push-Location $ProjectDir
    $SourceFiles = Get-ChildItem -Path "src\main\java\fate" -Include "*.java" -Recurse | ForEach-Object { $_.FullName }
    
    Write-Host "Compiling with javac (Java 17)..." -ForegroundColor Cyan
    & javac -d target/classes -encoding UTF-8 -cp "$H2JAR;$MYSQL_JAR" --release 17 $SourceFiles
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Compilation failed!" -ForegroundColor Red
        Pop-Location
        exit 1
    }
    Write-Host "Compilation successful!" -ForegroundColor Green
    Pop-Location
}

# Copy resources
Write-Host "Preparing resources..." -ForegroundColor Cyan
Copy-Item "$ProjectDir\src\main\resources\db.properties" "$ProjectDir\target\classes\" -Force -ErrorAction SilentlyContinue

# Run the application
Write-Host ""
Write-Host "╔════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║  FATE - Alternate Academic Timeline Simulator          ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""

Set-Location $ProjectDir
& java -cp "target/classes;$H2JAR;$MYSQL_JAR" fate.Main

