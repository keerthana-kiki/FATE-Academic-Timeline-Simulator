@echo off
REM FATE - Alternate Academic Timeline Simulator
REM Quick Run Script

setlocal enabledelayedexpansion

REM Set paths
set "PROJECT_DIR=%~dp0"
set "H2_JAR=%USERPROFILE%\.m2\repository\com\h2database\h2\2.2.220\h2-2.2.220.jar"
set "MYSQL_JAR=%USERPROFILE%\.m2\repository\com\mysql\mysql-connector-j\8.0.33\mysql-connector-j-8.0.33.jar"

REM Check if jars exist
if not exist "!H2_JAR!" (
    echo Error: H2 JAR not found at !H2_JAR!
    echo Please run: mvn dependency:resolve
    exit /b 1
)

if not exist "!MYSQL_JAR!" (
    echo Error: MySQL JAR not found at !MYSQL_JAR!
    echo Please run: mvn dependency:resolve
    exit /b 1
)

REM Check if compiled classes exist
if not exist "target\classes\fate\Main.class" (
    echo Error: Application not compiled. Compiling now...
    call :compile
    if errorlevel 1 exit /b 1
)

REM Run the application
echo.
echo Starting FATE - Alternate Academic Timeline Simulator...
echo.
cd /d "!PROJECT_DIR!"
java -cp "target/classes;!H2_JAR!;!MYSQL_JAR!" fate.Main
exit /b 0

:compile
echo Compiling...
javac -d target\classes -encoding UTF-8 -cp "!H2_JAR!;!MYSQL_JAR!" --release 17 ^
    src\main\java\fate\*.java ^
    src\main\java\fate\dao\*.java ^
    src\main\java\fate\db\*.java ^
    src\main\java\fate\model\*.java ^
    src\main\java\fate\service\*.java ^
    src\main\java\fate\util\*.java
if errorlevel 1 (
    echo Compilation failed!
    exit /b 1
)
echo Compilation successful!
exit /b 0
