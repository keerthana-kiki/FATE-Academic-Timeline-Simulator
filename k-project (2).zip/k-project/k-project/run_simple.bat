@echo off
REM Simple FATE Run Script - Windows Batch

set "H2JAR=%USERPROFILE%\.m2\repository\com\h2database\h2\2.2.220\h2-2.2.220.jar"
set "MYSQLJAR=%USERPROFILE%\.m2\repository\com\mysql\mysql-connector-j\8.0.33\mysql-connector-j-8.0.33.jar"

cd /d "%~dp0"

echo ========================================
echo FATE - Academic Timeline Simulator
echo ========================================
echo.

java -cp "target\classes;%H2JAR%;%MYSQLJAR%" fate.Main

pause
